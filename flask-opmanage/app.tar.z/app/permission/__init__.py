from flask import Blueprint

permission = Blueprint('permission',__name__)
from . import views