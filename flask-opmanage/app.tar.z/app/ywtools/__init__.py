from flask import Blueprint

ywtools = Blueprint('ywtools',__name__)
from . import views