from flask import Blueprint

setopentime = Blueprint('setopentime',__name__)
from . import views